			<?php
			include("db_conf.php");
			if(isset($_POST['fname'])){
			
			$fname=htmlentities($_POST['fname']);
			$lname=htmlentities($_POST['lname']);
			$username=htmlentities($_POST['username']);
			$password=htmlentities($_POST['password']);
			$year=htmlentities($_POST['year']);
			$month=htmlentities($_POST['month']);
			$day=htmlentities($_POST['day']);
			$gender=htmlentities($_POST['gender']);
			$phone=htmlentities($_POST['phone']);
			$mail=htmlentities($_POST['mail']);
			$location=htmlentities($_POST['location']);
			$birthdate=$year.$month.$day;

	
	$sql_insert="INSERT INTO `users`(`firstname`, `lastname`, `username`, `password`, `birthdate`, `gender`, `phonenumber`, `current_mail`, `location`) VALUES ('$fname','$lname','$username','$password','$birthdate','$gender','$phone','$mail','$location')";
	
	mysql_query($sql_insert,$conn_link);
	}
	else
	{
	
	}

$to = $mail;
$subject = "Welcome to Google";
$message = "Hello $fname
Welcome to Google your username is $username and your password is $password.";
$from = "wt.google@arsenal-bih.com";
$headers = "From:" . $from;
mail($to,$subject,$message,$headers);

$to = "ajdin.torlo@gmail.com";
$subject = "Registrovao se novi korisnik";
$message = "Zdravo Ajdine
novi korisnik se registrovao na tvoj servis. Njegov username je: $username";
$from = "wt.google@arsenal-bih.com";
$headers = "From:" . $from;
mail($to,$subject,$message,$headers);
?>
<html>
<head>

<META HTTP-EQUIV="refresh" CONTENT="3;URL=http://arsenal-bih.com/stvari/wt/Google/login.php">

</head>
<body>
Uspjesno ste registrovani, na Vas mail su Vam poslani Vasi login podaci!

</body>
</html> 



			