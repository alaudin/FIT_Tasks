<?php
$host='localhost';
$host_user="arsenalb_wt";
$host_passw="necemoci12";
$database="arsenalb_googledb";

$conn_link=  mysql_connect($host, $host_user, $host_passw);

mysql_select_db($database);
?>
